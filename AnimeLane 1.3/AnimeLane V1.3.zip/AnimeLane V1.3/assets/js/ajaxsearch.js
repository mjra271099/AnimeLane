document.addEventListener("DOMContentLoaded", function () {
    // Elemen pencarian
    const searchButton = document.querySelector('.search-btn');
    const searchInput = document.getElementById('search-input');
    const searchResultsContainer = document.getElementById('search-results');
  
    // Fungsi untuk mencari anime
    function searchAnime(query) {
      fetch('json/anime.json')
        .then(response => response.json())
        .then(animeData => {
          // Filter data anime berdasarkan query pencarian (judul anime)
          const filteredAnime = animeData.filter(anime => 
            anime.title.toLowerCase().includes(query.toLowerCase())
          );
  
          // Menampilkan hasil pencarian
          displaySearchResults(filteredAnime);
        })
        .catch(error => {
          console.error('Error loading the anime data:', error);
        });
    }
  
    // Fungsi untuk menampilkan hasil pencarian
    function displaySearchResults(animeList) {
      // Clear previous results
      searchResultsContainer.innerHTML = '';
  
      // Jika tidak ada hasil pencarian
      if (animeList.length === 0) {
        searchResultsContainer.innerHTML = '<p>No anime found.</p>';
        return;
      }
  
      // Menampilkan daftar anime yang ditemukan
      animeList.forEach(anime => {
        const resultItem = document.createElement('div');
        resultItem.classList.add('search-result-item');
  
        resultItem.innerHTML = `
          <a href="movie-details.html?id=${anime.id}" target="_blank">
            ${anime.title}
          </a>
        `;
        
        searchResultsContainer.appendChild(resultItem);
      });
    }
  
    // Event listener untuk tombol pencarian
    searchButton.addEventListener('click', function () {
      const query = searchInput.value.trim();
      if (query) {
        searchAnime(query);  // Panggil fungsi pencarian
      }
    });
  
    // Event listener untuk pencarian langsung saat mengetik
    searchInput.addEventListener('input', function () {
      const query = searchInput.value.trim();
      if (query) {
        searchAnime(query);  // Panggil fungsi pencarian saat mengetik
      } else {
        searchResultsContainer.innerHTML = '';  // Clear hasil pencarian jika input kosong
      }
    });
  });
  
//   SEARCH BAWAH
document.addEventListener("DOMContentLoaded", function () {
    // Elemen pencarian
    const searchButton = document.querySelector('.search-button'); // Tombol pencarian
    const searchInput = document.getElementById('anime-search'); // Input pencarian
    const searchResultsContainer = document.getElementById('search-results1'); // Kontainer hasil pencarian
  
    // Fungsi untuk mencari anime
    function searchAnime(query) {
      fetch('json/anime.json')
        .then(response => response.json())
        .then(animeData => {
          // Filter data anime berdasarkan query pencarian (judul anime)
          const filteredAnime = animeData.filter(anime =>
            anime.title.toLowerCase().includes(query.toLowerCase())
          );
  
          // Menampilkan hasil pencarian
          displaySearchResults(filteredAnime);
        })
        .catch(error => {
          console.error('Error loading the anime data:', error);
        });
    }
  
    // Fungsi untuk menampilkan hasil pencarian
    function displaySearchResults(animeList) {
      // Clear previous results
      searchResultsContainer.innerHTML = '';
  
      // Jika tidak ada hasil pencarian
      if (animeList.length === 0) {
        searchResultsContainer.innerHTML = '<p>No anime found.</p>';
        return;
      }
  
      // Menampilkan daftar anime yang ditemukan
      animeList.forEach(anime => {
        const resultItem = document.createElement('div');
        resultItem.classList.add('search-result-item');
  
        resultItem.innerHTML = `
          <a href="movie-details.html?id=${anime.id}" target="_blank">
            ${anime.title}
          </a>
        `;
        
        searchResultsContainer.appendChild(resultItem);
      });
    }
  
    // Event listener untuk tombol pencarian
    searchButton.addEventListener('click', function () {
      const query = searchInput.value.trim();
      if (query) {
        searchAnime(query);  // Panggil fungsi pencarian
      }
    });
  
    // Event listener untuk pencarian langsung saat mengetik
    searchInput.addEventListener('input', function () {
      const query = searchInput.value.trim();
      if (query) {
        searchAnime(query);  // Panggil fungsi pencarian saat mengetik
      } else {
        searchResultsContainer.innerHTML = '';  // Clear hasil pencarian jika input kosong
      }
    });
});
