// Mengaktifkan dan meng-install service worker
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open('my-cache-v1').then((cache) => {
            return cache.addAll([
                '/',
                '/index.html',          // File utama di root folder
                '/movie.html',
                '/movie-details.html',
                '/index-anime.html',
                '/iframe.html',
                '/404.html',

                // File di subfolder
                '/assets/css/style.css',  // File CSS di folder 'assets/css'
                '/assets/css/ajaxcss.css',  // File CSS di folder 'assets/css'
                '/assets/css/indexanime.css',  // File CSS di folder 'assets/css'
                '/assets/css/marque.css',  // File CSS di folder 'assets/css'
                '/assets/css/othercss.css',  // File CSS di folder 'assets/css'
                '/assets/css/preloader.css',  // File CSS di folder 'assets/css'
                '/assets/css/style-index.css',  // File CSS di folder 'assets/css'
                '/assets/css/style-movie.css',  // File CSS di folder 'assets/css'
                '/assets/css/iframe.css',  // File CSS di folder 'assets/css'

                '/assets/js/ajaxsearch.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/editlink.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/episode.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/genremovie.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/getepisode.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/iframe.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/indexanime.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/movie-details.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/movie.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/preloader.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/script.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/top-rated.js',    // File JavaScript di folder 'assets/js'
                '/assets/js/uncoming.js',    // File JavaScript di folder 'assets/js'

                '/assets/images/hero-bgker.jpg', // Gambar di folder 'assets/images'

            ]);
        })
    );
});

// Menangani permintaan dan memberikan file dari cache atau server
self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request).then((response) => {
            if (response) {
                return response;  // Ambil dari cache jika ada
            }
            return fetch(event.request);  // Ambil dari server jika tidak ada
        })
    );
});

// Menghapus cache lama (versi sebelumnya)
self.addEventListener('activate', (event) => {
    const cacheWhitelist = ['my-cache-v1'];  // Cache versi yang ingin dipertahankan
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (!cacheWhitelist.includes(cacheName)) {
                        return caches.delete(cacheName);  // Hapus cache lama
                    }
                })
            );
        })
    );
});


self.addEventListener('install', (event) => {
    console.log('Service worker installed');
});

self.addEventListener('fetch', (event) => {
    // Bisa ditambahkan caching di sini
    console.log('Fetching:', event.request.url);
});
